"""Local Flask web interface for SentinelLog. Run with: python3 app.py"""
from pathlib import Path
from werkzeug.utils import secure_filename
from flask import Flask, render_template, request, send_from_directory, flash, redirect, url_for
from parser import parse_auth_log, parse_access_log
from detector import run_all_detections
from report import save_report, save_json, save_csv
from utils import ensure_dir

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "instance" / "uploads"
REPORT_DIR = BASE_DIR / "reports"
ALLOWED_EXTENSIONS = {"log", "txt"}
MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5 MiB per request

app = Flask(__name__)
app.secret_key = "sentinel-log-local-ui-change-this-key"
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH



@app.context_processor
def shared_dashboard_context():
    """Data used by all panels in the single-page local dashboard."""
    rules = [
        {"severity": "HIGH", "name": "Successful Login After Repeated Failures",
         "condition": "A successful login follows repeated failures from the same IP within the configured time window.",
         "purpose": "Highlights a possible account compromise for analyst review."},
        {"severity": "HIGH / MEDIUM", "name": "Suspicious Web Path Probing",
         "condition": "Requests match sensitive paths such as /.env, /.git/config, backup files, or common admin paths.",
         "purpose": "Identifies attempts to locate exposed configuration or administrative resources."},
        {"severity": "HIGH / MEDIUM", "name": "Repeated Failed Login Attempts",
         "condition": "Failed SSH logins from one IP reach the configured threshold inside the selected time window.",
         "purpose": "Flags possible password guessing or brute-force activity."},
        {"severity": "MEDIUM", "name": "Multiple Invalid Usernames Attempted",
         "condition": "At least five distinct usernames are observed for one source IP.",
         "purpose": "May indicate username enumeration or broad account guessing."},
        {"severity": "MEDIUM", "name": "Repeated 404 Requests",
         "condition": "At least twenty HTTP 404 responses are observed for one source IP in the analyzed access log.",
         "purpose": "May indicate path discovery or scanning."},
        {"severity": "LOW", "name": "High Request Frequency",
         "condition": "At least two hundred total requests are observed for one IP in the analyzed file.",
         "purpose": "Highlights high-volume activity; this rule is not a time-rate calculation."},
    ]
    descriptions = {
        "report.txt": ("Text report", "Human-readable findings and evidence."),
        "report.json": ("JSON report", "Structured output for scripting and integrations."),
        "report.csv": ("CSV report", "Tabular output for spreadsheets and triage."),
    }
    ensure_dir(str(REPORT_DIR))
    reports = []
    for filename, (label, description) in descriptions.items():
        path = REPORT_DIR / filename
        reports.append({"filename": filename, "label": label, "description": description,
                        "exists": path.is_file(), "size": path.stat().st_size if path.is_file() else 0})
    return {"dashboard_rules": rules, "dashboard_reports": reports}


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def analyze(auth_path=None, access_path=None, window_minutes=5, threshold=5, sources=None):
    auth_events = parse_auth_log(str(auth_path)) if auth_path else []
    access_events = parse_access_log(str(access_path)) if access_path else []
    alerts = run_all_detections(auth_events, access_events, window_minutes, threshold)
    source_names = sources or []
    ensure_dir(str(REPORT_DIR))
    save_report(alerts, str(REPORT_DIR / "report.txt"), source_names)
    save_json(alerts, str(REPORT_DIR / "report.json"), source_names)
    save_csv(alerts, str(REPORT_DIR / "report.csv"))
    return alerts, auth_events, access_events


@app.get("/")
def index():
    return render_template("index.html", alerts=None, auth_count=0, access_count=0, counts={}, settings={"window": 5, "threshold": 5}, active="overview")


@app.post("/analyze-samples")
def analyze_samples():
    try:
        window = max(1, min(1440, int(request.form.get("window_minutes", "5"))))
        threshold = max(1, min(1000, int(request.form.get("threshold", "5"))))
        alerts, auth_events, access_events = analyze(
            BASE_DIR / "logs" / "auth.log", BASE_DIR / "logs" / "access.log",
            window, threshold, ["logs/auth.log", "logs/access.log"]
        )
        counts = {level: sum(a.get("severity") == level for a in alerts) for level in ("HIGH", "MEDIUM", "LOW")}
        return render_template("index.html", alerts=alerts, auth_count=len(auth_events), access_count=len(access_events), counts=counts, settings={"window": window, "threshold": threshold}, mode="Sample logs", active="overview")
    except (OSError, ValueError) as exc:
        flash(f"Could not analyze sample logs: {exc}", "error")
        return redirect(url_for("index"))


@app.post("/analyze-upload")
def analyze_upload():
    auth_file = request.files.get("auth_file")
    access_file = request.files.get("access_file")
    if not ((auth_file and auth_file.filename) or (access_file and access_file.filename)):
        flash("Choose at least one authentication or web-access log file.", "error")
        return redirect(url_for("index"))
    for uploaded in (auth_file, access_file):
        if uploaded and uploaded.filename and not allowed_file(uploaded.filename):
            flash("Only .log and .txt files are accepted.", "error")
            return redirect(url_for("index"))
    try:
        window = max(1, min(1440, int(request.form.get("window_minutes", "5"))))
        threshold = max(1, min(1000, int(request.form.get("threshold", "5"))))
        ensure_dir(str(UPLOAD_DIR))
        paths, names = {}, []
        for key, uploaded in (("auth", auth_file), ("access", access_file)):
            if uploaded and uploaded.filename:
                safe_name = secure_filename(uploaded.filename) or f"{key}.log"
                destination = UPLOAD_DIR / f"{key}_{safe_name}"
                uploaded.save(destination)
                paths[key] = destination
                names.append(uploaded.filename)
        alerts, auth_events, access_events = analyze(paths.get("auth"), paths.get("access"), window, threshold, names)
        counts = {level: sum(a.get("severity") == level for a in alerts) for level in ("HIGH", "MEDIUM", "LOW")}
        return render_template("index.html", alerts=alerts, auth_count=len(auth_events), access_count=len(access_events), counts=counts, settings={"window": window, "threshold": threshold}, mode="Uploaded logs", active="overview")
    except (OSError, ValueError) as exc:
        flash(f"Analysis failed: {exc}", "error")
        return redirect(url_for("index"))



@app.get("/rules")
def rules_page():
    rules = [
        {"severity": "HIGH", "name": "Successful Login After Repeated Failures", "condition": "A successful login follows at least 3 failed attempts from the same IP within 10 minutes.", "purpose": "Highlights a possible account compromise; analyst validation is required."},
        {"severity": "HIGH / MEDIUM", "name": "Suspicious Web Path Probing", "condition": "At least 3 requests or 3 unique paths match the configured sensitive-path list. Five or more unique paths raises severity to HIGH.", "purpose": "Identifies attempts to locate exposed configuration, backup, or common admin paths."},
        {"severity": "HIGH / MEDIUM", "name": "Repeated Failed Login Attempts", "condition": "Failed SSH logins from one IP reach the user-configured threshold inside the selected time window. HIGH begins at 10 failures.", "purpose": "Flags possible password guessing or brute-force behavior."},
        {"severity": "MEDIUM", "name": "Multiple Invalid Usernames Attempted", "condition": "At least 5 distinct usernames are observed for one IP.", "purpose": "May indicate username enumeration or broad account guessing."},
        {"severity": "MEDIUM", "name": "Repeated 404 Requests", "condition": "At least 20 HTTP 404 responses from one IP in the analyzed access log.", "purpose": "May indicate path discovery or scanning."},
        {"severity": "LOW", "name": "High Request Frequency", "condition": "At least 200 total access-log requests from one IP in the analyzed file.", "purpose": "Highlights high-volume activity for review; this is not a time-rate calculation."},
    ]
    return render_template("rules.html", rules=rules, active="rules")


@app.get("/reports")
def reports_page():
    ensure_dir(str(REPORT_DIR))
    report_info = []
    descriptions = {
        "report.txt": ("Text report", "Human-readable findings and evidence."),
        "report.json": ("JSON report", "Structured output for scripting and integrations."),
        "report.csv": ("CSV report", "Tabular output for spreadsheets and triage."),
    }
    for filename, (label, description) in descriptions.items():
        path = REPORT_DIR / filename
        report_info.append({"filename": filename, "label": label, "description": description,
                            "exists": path.is_file(), "size": path.stat().st_size if path.is_file() else 0})
    return render_template("reports.html", reports=report_info, active="reports")

@app.get("/reports/<path:filename>")
def download_report(filename):
    if filename not in {"report.txt", "report.json", "report.csv"}:
        flash("That report type is not available.", "error")
        return redirect(url_for("index"))
    return send_from_directory(REPORT_DIR, filename, as_attachment=True)


@app.errorhandler(413)
def file_too_large(_error):
    flash("Upload too large. Keep the total request under 5 MiB.", "error")
    return redirect(url_for("index"))


if __name__ == "__main__":
    ensure_dir(str(UPLOAD_DIR))
    ensure_dir(str(REPORT_DIR))
    # Localhost only: uploaded logs and reports are intended for the local analyst.
    app.run(host="127.0.0.1", port=5000, debug=False)
